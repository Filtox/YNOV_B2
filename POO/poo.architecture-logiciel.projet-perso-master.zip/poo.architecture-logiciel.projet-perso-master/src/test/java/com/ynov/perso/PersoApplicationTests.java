package com.ynov.perso;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersoApplicationTests {

	@Test
	void contextLoads() {
	}

}
